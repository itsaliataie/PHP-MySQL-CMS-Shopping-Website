<?php
session_start();
require_once 'config/connect.php';
include 'include/header.php';
include 'include/nav.php'; ?>

<?php

if(isset($_POST) & !empty($_POST)){
		$pass = trim($_POST['password1']);
		$pass2 = trim($_POST['password2']);
		$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
		if(strlen($pass) < 6) {
			$fmsg = "Password cannot be less than 6 characters.";
		} elseif ( !preg_match("#[0-9]+#", $pass) ) {
		  $fmsg = "Password must contain at least one number.";
		} elseif ( !preg_match("#[a-z]+#", $pass) ) {
		  $fmsg = "Password must contain at least one letter.";
		} elseif ( !preg_match("#[A-Z]+#", $pass) ) {
		  $fmsg = "Password must contain at least one capital letter.";
		} elseif ( !preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $pass) ) {
		  $fmsg = "Password must contain at least one symbol.";
		} else {
			if (strcmp($pass, $pass2) == 0) {
				$password = password_hash($_POST['password1'], PASSWORD_DEFAULT);
				$query = "SELECT * FROM users WHERE email='$email'";
				$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
				$count = mysqli_num_rows($result);
				if($count == 1){
					$fmsg = "E-mail already exists";
				} else{
					$query = "INSERT INTO users (email, password) VALUES ('$email', '$password1')";
					$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
					if($result){
						$_SESSION['customer'] = $email;
						$_SESSION['customerid'] = mysqli_insert_id($connection);
						header("location: index.php");
					} else{
						header("location: login.php?message=2");
					}
				}
			} else {
				$fmsg = "passwords do not match!";
			}

		}
}

 ?>

	<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>Shop - Account</h2>
						<p>Login or Register</p>
					</div>
					<div class="col-md-12">
				<div class="row shop-login">
				<div class="col-md-6">
					<div class="box-content">
						<h3 class="heading text-center">I'm a Returning Customer</h3>
						<div class="clearfix space40"></div>
						<?php if(isset($_GET['message'])){
								if($_GET['message'] == 1){
						 ?><div class="alert alert-danger" role="alert"> <?php echo "Invalid Login Credentials"; ?> </div>

						 <?php } }?>
						<form class="logregform" method="post" action="loginprocess.php">
							<div class="row">
								<div class="form-group">
									<div class="col-md-12">
										<label>E-mail Address</label>
										<input type="email" name="email" value="" class="form-control" required>
									</div>
								</div>
							</div>
							<div class="clearfix space20"></div>
							<div class="row">
								<div class="form-group">
									<div class="col-md-12">
										<label>Password</label>
										<input type="password" name="password" value="" class="form-control" required>
									</div>
								</div>
							</div>
							<div class="clearfix space20"></div>
							<div class="row">
								<div class="col-md-6">
								</div>
								<div class="col-md-6">
									<button type="submit" class="button btn-md pull-right">Login</button>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-6">
					<div class="box-content">
						<h3 class="heading text-center">Register An Account</h3>
						<div class="clearfix space40"></div>
						<?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
						<?php if(isset($_GET['message'])){
								if($_GET['message'] == 2){
							?><div class="alert alert-danger" role="alert"> <?php echo "Failed to Register"; ?> </div>
							<?php } } ?>
						<form class="logregform" method="post" action="login.php">
							<div class="row">
								<div class="form-group">
									<div class="col-md-12">
										<label>E-mail Address</label>
										<input type="email" name="email" value="" class="form-control" required>
									</div>
								</div>
							</div>
							<div class="clearfix space20"></div>
							<div class="row">
								<div class="form-group">
									<div class="col-md-6">
										<label>Password</label>
										<input type="password" name="password1" value="" class="form-control" required>
									</div>
									<div class="col-md-6">
										<label>Re-enter Password</label>
										<input type="password" name="password2" value="" class="form-control" required>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="space20"></div>
									<button type="submit" class="button btn-md pull-right">Register</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>



					</div>
				</div>
			</div>
		</div>
	</section>

<?php include 'include/footer.php' ?>
