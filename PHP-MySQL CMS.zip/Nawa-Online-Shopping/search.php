<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="resulttest.php" method="post">
      <input type="text" name="productSearch" placeholder="Type your desired product here...">
      <button type="submit" name="search" value="Search"></button>
    </form>
  </body>
</html>
