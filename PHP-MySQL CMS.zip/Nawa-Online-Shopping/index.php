<?php
session_start();
require_once 'config/connect.php';
include 'include/header.php'; ?>
<?php include 'include/nav.php'; ?>

	<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>Shop</h2>
						<p>You can order products from here</p>
					</div>
					<div class="col-md-12">
						<div class="row">
							<div id="shop-mason" class="shop-mason-4col">

							<?php
								$query = "SELECT * FROM products";
								if(isset($_POST['id']) & !empty($_POST['id'])){
									$id = $_POST['id'];
									$query .= " WHERE catid=$id";
								}


								$result = mysqli_query($connection, $query);
								while($r = mysqli_fetch_assoc($result)){
							?>
								<div class="sm-item isotope-item">
									<div class="product">
										<div class="product-thumb">
											<img src="admin/<?php echo $r['thumb']; ?>" class="img-responsive" width="250px" alt="">
											<div class="product-overlay">
												<span>
												<a href="single.php?id=<?php echo $r['id']; ?>" class="fa fa-link"></a>
												<a href="addtocart.php?id=<?php echo $r['id']; ?>" class="fa fa-shopping-cart"></a>
												</span>
											</div>
										</div>

										<h2 class="product-title"><a href="single.php?id=<?php echo $r['id']; ?>"><?php echo $r['name']; ?></a></h2>
										<div class="product-price">Afs <?php echo $r['price']; ?>.00<span></span></div>
									</div>
								</div>
							<?php } ?>


							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>
<?php include 'include/footer.php' ?>
