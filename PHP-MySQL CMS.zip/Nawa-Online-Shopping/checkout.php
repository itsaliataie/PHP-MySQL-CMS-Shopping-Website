<?php
	ob_start();
	session_start();
	require_once 'config/connect.php';
	if(!isset($_SESSION['customer']) & empty($_SESSION['customer'])){
		header('location: login.php');
	}
include 'include/header.php';
include 'include/nav.php';
$uid = $_SESSION['customerid'];
$cart = $_SESSION['cart'];

if(isset($_POST) & !empty($_POST)){
	if($_POST['agree'] == true){
		$country = filter_var($_POST['country'], FILTER_SANITIZE_STRING);
		$fname = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
		$lname = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
		$company = filter_var($_POST['company'], FILTER_SANITIZE_STRING);
		$address1 = filter_var($_POST['address1'], FILTER_SANITIZE_STRING);
		$address2 = filter_var($_POST['address2'], FILTER_SANITIZE_STRING);
		$city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
		$state = filter_var($_POST['state'], FILTER_SANITIZE_STRING);
		$phone = filter_var($_POST['phone'], FILTER_SANITIZE_NUMBER_INT);
		$payment = filter_var($_POST['payment'], FILTER_SANITIZE_STRING);
		$zip = filter_var($_POST['zipcode'], FILTER_SANITIZE_NUMBER_INT);

		//Valudation
		if ( preg_match("#[0-9]+#", $fname) || preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $fname) ) {
		  $fmsg = "First Name field should only contain letters.";
		} elseif ( preg_match("#[0-9]+#", $lname) || preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $lname) ) {
		  $fmsg = "Last Name field should only contain letters.";
		} elseif ( preg_match("#[0-9]+#", $city) || preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $city) ) {
		  $fmsg = "City field should only contain letters.";
		} elseif ( preg_match("#[0-9]+#", $state) || preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $state) ) {
		  $fmsg = "State field should only contain letters.";
		} elseif ( !preg_match("#[0-9]+#", $phone) || preg_match("#[a-zA-Z]+#", $phone) || preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $phone)) {
		  $fmsg = "Phone must be only digits.";
		} elseif ( strlen($phone) != 10) {
			$fmsg = "Phone number must be 10 digits.";
		} elseif ( !preg_match("#[0-9]+#", $zip) || preg_match("#[a-zA-Z]+#", $zip) || preg_match("/[\'^£$%&*()}{@#~?><>,|=_+!-]/", $zip)) {
		  $fmsg = "Zipcode must be only digits.";
		} elseif ( strlen($zip) != 10) {
			$fmsg = "Zipcode must be 10 digits.";
		} else {
			$query = "SELECT * FROM usersmeta WHERE uid=$uid";
			$result = mysqli_query($connection, $query);
			$r = mysqli_fetch_assoc($result);
			$count = mysqli_num_rows($result);
			if($count == 1){
				$userQuery = "UPDATE usersmeta SET country='$country', firstname='$fname', lastname='$lname', address1='$address1', address2='$address2', city='$city', state='$state',  zip='$zip', company='$company', mobile='$phone' WHERE uid=$uid";
				$userReult = mysqli_query($connection, $userQuery) or die(mysqli_error($connection));
				if($userReult){

					$total = 0;
					foreach ($cart as $key => $value) {
						$orderQuery = "SELECT * FROM products WHERE id=$key";
						$orderResult = mysqli_query($connection, $orderQuery);
						$orderr = mysqli_fetch_assoc($orderResult);

						$total = $total + ($orderr['price']*$value['quantity']);
					}

					echo $insertQuery = "INSERT INTO orders (uid, totalprice, orderstatus, paymentmode) VALUES ('$uid', '$total', 'Order Placed', '$payment')";
					$insertResult = mysqli_query($connection, $insertQuery) or die(mysqli_error($connection));
					if($insertResult){
						$orderid = mysqli_insert_id($connection);
						foreach ($cart as $key => $value) {

							$orderQuery = "SELECT * FROM products WHERE id=$key";
							$orderResult = mysqli_query($connection, $orderQuery);
							$orderr = mysqli_fetch_assoc($orderResult);

							$pid = $orderr['id'];
							$productprice = $orderr['price'];
							$quantity = $value['quantity'];

							$orderItemQuery = "INSERT INTO orderitems (pid, orderid, productprice, pquantity) VALUES ('$pid', '$orderid', '$productprice', '$quantity')";
							$orderItemResult = mysqli_query($connection, $orderItemQuery) or die(mysqli_error($connection));
						}
					}
					unset($_SESSION['cart']);
					header("location: my-account.php");
				}
			}else{

				$insertQuery = "INSERT INTO usersmeta (country, firstname, lastname, address1, address2, city, state, zip, company, mobile, uid) VALUES ('$country', '$fname', '$lname', '$address1', '$address2', '$city', '$state', '$zip', '$company', '$phone', '$uid')";
				$insertResult = mysqli_query($connection, $insertQuery) or die(mysqli_error($connection));
				if($insertResult){

					$total = 0;
					foreach ($cart as $key => $value) {
						$orderQuery = "SELECT * FROM products WHERE id=$key";
						$orderResult = mysqli_query($connection, $orderQuery);
						$orderr = mysqli_fetch_assoc($orderResult);

						$total = $total + ($orderr['price']*$value['quantity']);
					}

					echo $insertQuery = "INSERT INTO orders (uid, totalprice, orderstatus, paymentmode) VALUES ('$uid', '$total', 'Order Placed', '$payment')";
					$insertResult = mysqli_query($connection, $insertQuery) or die(mysqli_error($connection));
					if($insertResult){

						$orderid = mysqli_insert_id($connection);
						foreach ($cart as $key => $value) {

							$orderQuery = "SELECT * FROM products WHERE id=$key";
							$orderResult = mysqli_query($connection, $orderQuery);
							$orderr = mysqli_fetch_assoc($orderResult);

							$pid = $orderr['id'];
							$productprice = $orderr['price'];
							$quantity = $value['quantity'];


							$orderItemQuery = "INSERT INTO orderitems (pid, orderid, productprice, pquantity) VALUES ('$pid', '$orderid', '$productprice', '$quantity')";
							$insertResult = mysqli_query($connection, $orderItemQuery) or die(mysqli_error($connection));
						}
					}
					unset($_SESSION['cart']);
					header("location: my-account.php");
				}

			}
		}

	}

	$query = "SELECT * FROM usersmeta WHERE uid=$uid";
	$result = mysqli_query($connection, $query);
	$r = mysqli_fetch_assoc($result);

		}
?>


	<section id="content">
		<div class="content-blog">
					<div class="page_header text-center">
						<h2>Shop - Checkout</h2>
						<p>Checkout Your Items Here!</p>
					</div>
<form method="post">
<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<div class="billing-details">
						<?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
						<h3 class="uppercase">Billing Details</h3>
						<div class="space30"></div>
							<label class="">Country </label>
							<select name="country" class="form-control" required>
								<option value="">Select Country</option>
								<option value="AX">Aland Islands</option>
								<option value="AF">Afghanistan</option>
								<option value="AL">Albania</option>
								<option value="DZ">Algeria</option>
								<option value="AD">Andorra</option>
								<option value="AO">Angola</option>
								<option value="AI">Anguilla</option>
								<option value="AQ">Antarctica</option>
								<option value="AG">Antigua and Barbuda</option>
								<option value="AR">Argentina</option>
								<option value="AM">Armenia</option>
								<option value="AW">Aruba</option>
								<option value="AU">Australia</option>
								<option value="AT">Austria</option>
								<option value="AZ">Azerbaijan</option>
								<option value="BS">Bahamas</option>
								<option value="BH">Bahrain</option>
								<option value="BD">Bangladesh</option>
								<option value="BB">Barbados</option>
							</select>
							<div class="clearfix space20"></div>
							<div class="row">
								<div class="col-md-6">
									<label>First Name </label>
									<input name="fname" class="form-control" placeholder="" value="<?php if(!empty($r['firstname'])){ echo $r['firstname']; } elseif(isset($fname)){ echo $fname; } ?>" type="text" required>
								</div>
								<div class="col-md-6">
									<label>Last Name </label>
									<input name="lname" class="form-control" placeholder="" value="<?php if(!empty($r['lastname'])){ echo $r['lastname']; }elseif(isset($lname)){ echo $lname; } ?>" type="text" required>
								</div>
							</div>
							<div class="clearfix space20"></div>
							<label>Company Name</label>
							<input name="company" class="form-control" placeholder="" value="<?php if(!empty($r['company'])){ echo $r['company']; }elseif(isset($company)){ echo $company; } ?>" type="text">
							<div class="clearfix space20"></div>
							<label>Address </label>
							<input name="address1" class="form-control" placeholder="Street address" value="<?php if(!empty($r['address1'])){ echo $r['address1']; } elseif(isset($address1)){ echo $address1; } ?>" type="text" required>
							<div class="clearfix space20"></div>
							<input name="address2" class="form-control" placeholder="Apartment, suite, unit etc. (optional)" value="<?php if(!empty($r['address2'])){ echo $r['address2']; }elseif(isset($address2)){ echo $address2; } ?>" type="text" required>
							<div class="clearfix space20"></div>
							<div class="row">
								<div class="col-md-4">
									<label>City </label>
									<input name="city" class="form-control" placeholder="City" value="<?php if(!empty($r['city'])){ echo $r['city']; }elseif(isset($city)){ echo $city; } ?>" type="text" required>
								</div>
								<div class="col-md-4">
									<label>State</label>
									<input name="state" class="form-control" value="<?php if(!empty($r['state'])){ echo $r['state']; }elseif(isset($state)){ echo $state; } ?>" placeholder="State" type="text" required>
								</div>
								<div class="col-md-4">
									<label>Postcode </label>
									<input name="zipcode" class="form-control" placeholder="Postcode / Zip" value="<?php if(!empty($r['zip'])){ echo $r['zip']; }elseif(isset($zip)){ echo $zip; } ?>" type="text" required>
								</div>
							</div>
							<div class="clearfix space20"></div>
							<label>Phone </label>
							<input name="phone" class="form-control" id="billing_phone" placeholder="" value="<?php if(!empty($r['mobile'])){ echo $r['mobile']; }elseif(isset($phone)){ echo $phone; } ?>" type="text" required>
					</div>
				</div>

			</div>
			<?php
			$total = 0;
				foreach ($cart as $key => $value) {
					$cartQuery = "SELECT * FROM products WHERE id=$key";
					$cartResult = mysqli_query($connection, $cartQuery);
					$cartr = mysqli_fetch_assoc($cartResult);

				$total = $total + ($cartr['price']*$value['quantity']);
			} ?>
			<div class="cart_totals">
				<div class="col-md-6 push-md-6 no-padding">
					<h4 class="heading">Cart Totals</h4>
					<table class="table table-bordered col-md-6">
						<tbody>
							<tr>
								<th>Cart Subtotal</th>
								<td><span class="amount">Afs <?php echo $total; ?>.00</span></td>
							</tr>
							<tr>
								<th>Shipping</th>
								<td>
									Free Shipping
								</td>
							</tr>
							<tr>
								<th>Total Price</th>
								<td><strong><span class="amount">Afs <?php echo $total; ?>.00</span></strong> </td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>

			<div class="clearfix space30"></div>
			<h4 class="heading">Payment Method</h4>
			<div class="clearfix space20"></div>

			<div class="payment-method">
				<div class="row">

						<div class="col-md-4">
							<input name="payment" checked id="radio1" class="css-checkbox" type="radio" value="cod"><span>Cash On Delivery</span>
							<div class="space20"></div>
							<p>Pay when you receive your order.</p>
						</div>
				</div>
				<div class="space30"></div>

					<input name="agree" id="checkboxG2" class="css-checkbox" type="checkbox" value="true" required><span>I've read and accept the <a href="#">terms &amp; conditions</a></span>

				<div class="space30"></div>
				<input type="submit" class="button btn-lg" value="Pay Now">
			</div>
		</div>
</form>
		</div>
	</section>

<?php include 'include/footer.php' ?>
