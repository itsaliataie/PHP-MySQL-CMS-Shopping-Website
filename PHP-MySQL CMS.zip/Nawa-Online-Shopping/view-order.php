<?php
	ob_start();
	session_start();
	require_once 'config/connect.php';
	if(!isset($_SESSION['customer']) & empty($_SESSION['customer'])){
		header('location: login.php');
	}

include 'include/header.php';
include 'include/nav.php';
$uid = $_SESSION['customerid'];
$cart = $_SESSION['cart'];
?>

	<section id="content">
		<div class="content-blog content-account">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>My Account</h2>
					</div>
					<div class="col-md-12">

			<h3>Recent Orders</h3>
			<br>
			<table class="cart-table account-table table table-bordered">
				<thead>
					<tr>
						<th>Product Name</th>
						<th>Quantity</th>
						<th>Price</th>
						<th></th>
						<th>Total Price</th>
					</tr>
				</thead>
				<tbody>

				<?php

					if(isset($_GET['id']) & !empty($_GET['id'])){
						$oid = $_GET['id'];
					}else{
						header('location: my-account.php');
					}
					$orderQuery = "SELECT * FROM orders WHERE uid='$uid' AND id='$oid'";
					$orderResult = mysqli_query($connection, $orderQuery);
					$orderr = mysqli_fetch_assoc($orderResult);

					$orderItemQuery = "SELECT * FROM orderitems o JOIN products p WHERE o.orderid=3 AND o.pid=p.id";
					$orderItemResult = mysqli_query($connection, $orderItemQuery);
					while($orderItemr = mysqli_fetch_assoc($orderItemResult)){
				?>
					<tr>
						<td>
							<a href="single.php?id=<?php echo $orderItemr['pid']; ?>"><?php echo substr($orderItemr['name'], 0, 25); ?></a>
						</td>
						<td>
							<?php echo $orderItemr['pquantity']; ?>
						</td>
						<td>
							INR <?php echo $orderItemr['productprice']; ?>/-
						</td>
						<td>

						</td>
						<td>
							Afs <?php echo $orderItemr['productprice']*$orderItemr['pquantity']; ?>
						</td>
					</tr>
				<?php } ?>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td>
							Order Total
						</td>
						<td>
							<?php echo $ordr['totalprice']; ?>
						</td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td>
							Order Status
						</td>
						<td>
							<?php echo $ordr['orderstatus']; ?>
						</td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td>
							Order Placed On
						</td>
						<td>
							<?php echo $ordr['timestamp']; ?>
						</td>
					</tr>
				</tbody>
			</table>

			<br>
			<br>
			<br>

			<div class="ma-address">
						<h3>My Addresses</h3>
						<p>The following addresses will be used on the checkout page by default.</p>

			<div class="row">
				<div class="col-md-6">
								<h4>My Address <a href="edit-address.php">Edit</a></h4>
					<?php
						$cQuery = "SELECT u1.firstname, u1.lastname, u1.address1, u1.address2, u1.city, u1.state, u1.country, u1.company, u.email, u1.mobile, u1.zip FROM users u JOIN usersmeta u1 WHERE u.id=u1.uid AND u.id=$uid";
						$cResult = mysqli_query($connection, $cQuery);
						if(mysqli_num_rows($cResult) == 1){
							$cr = mysqli_fetch_assoc($cResult);
							echo "<p>".$cr['firstname'] ." ". $cr['lastname'] ."</p>";
							echo "<p>".$cr['address1'] ."</p>";
							echo "<p>".$cr['address2'] ."</p>";
							echo "<p>".$cr['city'] ."</p>";
							echo "<p>".$cr['state'] ."</p>";
							echo "<p>".$cr['country'] ."</p>";
							echo "<p>".$cr['company'] ."</p>";
							echo "<p>".$cr['zip'] ."</p>";
							echo "<p>".$cr['mobile'] ."</p>";
							echo "<p>".$cr['email'] ."</p>";
						}
					?>
				</div>

				<div class="col-md-6">

				</div>
			</div>



			</div>

					</div>
				</div>
			</div>
		</div>
	</section>

<?php include 'include/footer.php' ?>
