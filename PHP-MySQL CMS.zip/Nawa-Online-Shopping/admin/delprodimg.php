<?php
	session_start();
	require_once '../config/connect.php';
	if(!isset($_SESSION['email']) & empty($_SESSION['email'])){
		header('location: login.php');
	}

	if(isset($_GET['id']) & !empty($_GET['id'])){
		$id = $_GET['id'];
		$query = "SELECT thumb FROM products WHERE id=$id";
		$result = mysqli_query($connection, $query);
		$r = mysqli_fetch_assoc($result);
		if(!empty($r['thumb'])){
			if(unlink($r['thumb'])){
				$delQuery = "UPDATE products SET thumb='' WHERE id=$id";
				if(mysqli_query($connection, $delQuery)){
					header("location:editproduct.php?id={$id}");
				}
			}else{
				$delQuery = "UPDATE products SET thumb='' WHERE id=$id";
				if(mysqli_query($connection, $delQuery)){
					header("location:editproduct.php?id={$id}");
				}
			}

	}else{
		$delQuery = "UPDATE products SET thumb='' WHERE id=$id";
		if(mysqli_query($connection, $delQuery)){
			header("location:editproduct.php?id={$id}");
		}
	}
}else{
	header("location:editproduct.php?id={$id}");
}
