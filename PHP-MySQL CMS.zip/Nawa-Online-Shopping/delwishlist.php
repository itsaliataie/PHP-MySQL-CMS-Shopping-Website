<?php
ob_start();
session_start();
require_once 'config/connect.php';
$uid = $_SESSION['customerid'];
if(!isset($_SESSION['customer']) & empty($_SESSION['customer'])){
		header('location: login.php');
	}
if(isset($_GET['id']) & !empty($_GET['id'])){
	$id = $_GET['id'];
	echo $query = "DELETE FROM wishlist WHERE id=$id";
	$result = mysqli_query($connection, $query);
	if($result){
		header('location: wishlist.php');
	}
}else{
	header('location: wishlist.php');
}

?>
