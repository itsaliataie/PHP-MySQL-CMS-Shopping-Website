<?php
ob_start();
session_start();
require_once 'config/connect.php';
include 'include/header.php';
include 'include/nav.php';
if(isset($_GET['id']) & !empty($_GET['id'])){
	$id = $_GET['id'];
	$prodQuery = "SELECT * FROM products WHERE id=$id";
	$prodResult = mysqli_query($connection, $prodQuery);
	$prodr = mysqli_fetch_assoc($prodResult);
}else{
	header('location: index.php');
}

$uid = $_SESSION['customerid'];
if(isset($_POST) & !empty($_POST)){

	$review = filter_var($_POST['review'], FILTER_SANITIZE_STRING);

	$revQuery = "INSERT INTO reviews (pid, uid, review) VALUES ($id, $uid, '$review')";
	$revResult = mysqli_query($connection, $revQuery);
	if($revResult){
		$smsg = "Review Submitted Successfully";
	}else{
		$fmsg = "Failed to Submit Review";
	}
}

?>

	<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>Shop</h2>
						<p>You can view the product here!</p>
					</div>


					<div class="col-md-10 col-md-offset-1">
			<?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
			<?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
					<div class="row">
						<div class="col-md-5">
							<div class="gal-wrap">
								<div id="gal-slider" class="flexslider">
									<ul class="slides">
										<li><img src="admin/<?php echo $prodr['thumb']; ?>" class="img-responsive" alt=""/></li>
									</ul>
								</div>
								<ul class="gal-nav">
									<li>
										<div>
											<img src="admin/<?php echo $prodr['thumb']; ?>" class="img-responsive" alt=""/>
										</div>
									</li>
								</ul>
								<div class="clearfix"></div>

							</div>
						</div>
						<div class="col-md-7 product-single">
							<h2 class="product-single-title no-margin"><?php echo $prodr['name']; ?></h2>
							<div class="space10"></div>
							<div class="p-price">Afs <?php echo $prodr['price']; ?>.00</div>
							<p><?php echo $prodr['description']; ?></p>
							<form method="get" action="addtocart.php">
							<div class="product-quantity">
								<span>Quantity:</span>
									<input type="hidden" name="id" value="<?php echo $prodr['id']; ?>">
									<input type="text" name="quant" placeholder="1">
							</div>
							<div class="shop-btn-wrap">
								<input type="submit" class="button btn-small" value="Add to Cart">
							</div>
							</form>
							<a href="addtowishlist.php?id=<?php echo $prodr['id']; ?>">Add to WishList</a>
							<div class="product-meta">
								<span>Categories:
								<?php
								$prodcatQuery = "SELECT * FROM category WHERE id={$prodr['catid']}";
								$prodcatResult = mysqli_query($connection, $prodcatQuery);
								$prodcatr = mysqli_fetch_assoc($prodcatResult);
								?>
								<a href="#"><?php echo $prodcatr['name']; ?></a></span><br>
							</div>
						</div>
					</div>
					<div class="clearfix space30"></div>
					<div class="tab-style3">

						<div class="align-center mb-40 mb-xs-30">
							<ul class="nav nav-tabs tpl-minimal-tabs animate">
								<li class="active col-md-6">
									<a aria-expanded="true" href="#mini-one" data-toggle="tab">Overview</a>
								</li>

								<li class="col-md-6">
									<a aria-expanded="false" href="#mini-three" data-toggle="tab">Reviews</a>
								</li>
							</ul>
						</div>

						<div style="height: auto;" class="tab-content tpl-minimal-tabs-cont align-center section-text">
							<div style="" class="tab-pane fade active in" id="mini-one">
								<p>T<?php echo $prodr['description']; ?></p>
							</div>
							<div style="" class="tab-pane fade" id="mini-three">
								<div class="col-md-12">
								<?php
									$revcountQuery = "SELECT count(*) AS count FROM reviews r WHERE r.pid=$id";
									$revcountResult = mysqli_query($connection, $revcountQuery);
									$revcountr = mysqli_fetch_assoc($revcountResult);

								 ?>
									<h4 class="uppercase space35"><?php echo $revcountr['count']; ?> Reviews for <?php echo substr($prodr['name'], 0, 20); ?></h4>
									<ul class="comment-list">
									<?php
										$selrevQuery = "SELECT u.firstname, u.lastname, r.`timestamp`, r.review FROM reviews r JOIN usersmeta u WHERE r.uid=u.uid AND r.pid=$id";
										$selrevResult = mysqli_query($connection, $selrevQuery);
										while($selrevr = mysqli_fetch_assoc($selrevResult)){
									?>
										<li>
											<a class="pull-left" href="#"><img class="comment-avatar" src="images/quote/1.jpg" alt="" height="50" width="50"></a>
											<div class="comment-meta">
												<a href="#"><?php echo $selrevr['firstname']." ". $selrevr['lastname']; ?></a>
												<span>
												<em><?php echo $selrevr['timestamp']; ?></em>
												</span>
											</div>

											<p>
												<?php echo $selrevr['review']; ?>
											</p>
										</li>
									<?php } ?>
									</ul>
									<?php
										$chkrevQuery = "SELECT count(*) reviewcount FROM reviews r WHERE r.uid=$uid";
										$chkrevResult = mysqli_query($connection, $chkrevQuery);
										$chkrevr = mysqli_fetch_assoc($chkrevResult);
										if($chkrevr['reviewcount'] >= 1){
											echo "<h4 class='uppercase space20'>You have already Reviewed This Product...</h4>";
										}else{
									?>
									<h4 class="uppercase space20">Add a review</h4>
									<form id="form" class="review-form" method="post">
									<?php
										$userQuery = "SELECT u.email, u1.firstname, u1.lastname FROM users u JOIN usersmeta u1 WHERE u.id=u1.uid AND u.id=$uid";
										$userResult = mysqli_query($connection, $userQuery);
										$userr = mysqli_fetch_assoc($userResult);
									 ?>
										<div class="row">
											<div class="col-md-6 space20">
												<input name="name" class="input-md form-control" placeholder="Name *" maxlength="100" required="" type="text" value="<?php echo $userr['firstname'] . " " . $userr['lastname'];?>" disabled>
											</div>
											<div class="col-md-6 space20">
												<input name="email" class="input-md form-control" placeholder="Email *" maxlength="100" required="" type="email" value="<?php echo $userr['email']; ?>" disabled>
											</div>
										</div>

										<div class="space20">
											<textarea name="review" id="text" class="input-md form-control" rows="6" placeholder="Add review.." maxlength="400"></textarea>
										</div>
										<button type="submit" class="button btn-small" value="Submit Review"></button>
									</form>
									<?php } ?>
								</div>
								<div class="clearfix space30"></div>
							</div>
						</div>
					</div>
					<div class="space30"></div>
					<div class="related-products">
						<h4 class="heading">Related Products</h4>
						<hr>
						<div class="row">
							<div id="shop-mason" class="shop-mason-3col">

							<?php
								$relQuery = "SELECT * FROM products WHERE id != $id ORDER BY rand() LIMIT 3";
								$relResult = mysqli_query($connection, $relQuery);
								while($relr = mysqli_fetch_assoc($relResult)){
							 ?>
								<div class="sm-item isotope-item">
									<div class="product">
										<div class="product-thumb">
											<img src="admin/<?php echo $relr['thumb']; ?>" class="img-responsive" alt="">
											<div class="product-overlay">
												<span>
												<a href="single.php?id=<?php echo $relr['id']; ?>" class="fa fa-link"></a>
												<a href="#" class="fa fa-shopping-cart"></a>
												</span>
											</div>
										</div>
										<h2 class="product-title"><a href="#"><?php echo $relr['name']; ?></a></h2>
										<div class="product-price">Afs <?php echo $relr['price']; ?>.00<span></span></div>
									</div>
								</div>
							<?php } ?>
							</div>

						</div>
					</div>

					</div>
				</div>
			</div>
		</div>
	</section>

<?php include 'include/footer.php' ?>
