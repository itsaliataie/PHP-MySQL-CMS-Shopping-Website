<?php
$connection = mysqli_connect('localhost', 'root', 'root', 'NawaOnlineShop');
if(!$connection){
	echo "Error: Unable to connect to MySQL.";
    exit;
}
?>
