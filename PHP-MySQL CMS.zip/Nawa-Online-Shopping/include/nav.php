			<div class="menu-wrap" style="background: #1A76BA">
				<div id="mobnav-btn">Menu <i class="fa fa-bars"></i></div>
				<ul class="sf-menu">
					<li>
						<a href="http://localhost:8888/Nawa-Online-Shopping/index.php">Home</a>
					</li>
					<li>
						<a href="http://localhost:8888/Nawa-Online-Shopping/index.php">Shop</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
						<?php
							$catQuery = "SELECT * FROM category";
							$catResult = mysqli_query($connection, $catQuery);
							while($catr = mysqli_fetch_assoc($catResult)){
						 ?>
							<li><a href="index.php?id=<?php echo $catr['id']; ?>"><?php echo $catr['name']; ?></a></li>
						<?php } ?>
						</ul>
					</li>
					<li>
						<a href="http://localhost:8888/Nawa-Online-Shopping/my-account.php">My Account</a>
						<div class="mobnav-subarrow"><i class="fa fa-plus"></i></div>
						<ul>
							<li><a href="http://localhost:8888/Nawa-Online-Shopping/my-account.php">My Orders</a></li>
							<li><a href="http://localhost:8888/Nawa-Online-Shopping/edit-address.php">Update Address</a></li>
							<li><a href="http://localhost:8888/Nawa-Online-Shopping/logout.php">Logout</a></li>
						</ul>
					</li>
					<li>
						<a href="http://localhost:8888/Nawa-Online-Shopping/contact.php">Contact</a>
					</li>
					<li>
						<a href="http://localhost:8888/Nawa-Online-Shopping/wishlist.php">WishList</a>
					</li>
				</ul>
				<div class="header-xtra">
				<?php $cart = $_SESSION['cart']; ?>
					<div class="s-cart">
						<div class="sc-ico"><i class="fa fa-shopping-cart"></i><em><?php
								echo count($cart); ?></em></div>

						<div class="cart-info">
							<small>You have <em class="highlight"><?php
								echo count($cart); ?> item(s)</em> in your shopping cart</small>
							<br>
							<br>
							<?php
								$total = 0;
								foreach ($cart as $key => $value) {
									$navcartQuery = "SELECT * FROM products WHERE id=$key";
									$navcartResult = mysqli_query($connection, $navcartQuery);
									$navcartr = mysqli_fetch_assoc($navcartResult);


							 ?>
							<div class="ci-item">
								<img src="admin/<?php echo $navcartr['thumb']; ?>" width="70" alt=""/>
								<div class="ci-item-info">
									<h5><a href="single.php?id=<?php echo $navcartr['id']; ?>"><?php echo substr($navcartr['name'], 0 , 20); ?></a></h5>
									<p><?php echo $value['quantity']; ?> x Afs <?php echo $navcartr['price']; ?>.00</p>
									<div class="ci-edit">
										<a href="delcart.php?id=<?php echo $key; ?>" class="edit fa fa-trash"></a>
									</div>
								</div>
							</div>
							<?php
							$total = $total + ($navcartr['price']*$value['quantity']);
							} ?>
							<div class="ci-total">Subtotal: Afs <?php echo $total; ?>.00</div>
							<div class="cart-btn">
								<a href="cart.php">View Cart</a>
								<a href="checkout.php">Checkout</a>
							</div>
						</div>
					</div>
					<div class="s-search">
						<div class="ss-ico"><i class="fa fa-search"></i></div>
						<div class="search-block">
							<div class="ssc-inner">
								<form action="result.php" method="post">
									<input type="text" name="productSearch" placeholder="Type your desired product here...">
									<button type="submit" name="search"><i class="fa fa-search"></i></button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
