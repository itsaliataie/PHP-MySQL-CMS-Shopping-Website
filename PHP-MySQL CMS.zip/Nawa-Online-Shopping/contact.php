<?php
session_start();
require_once 'config/connect.php';
include 'include/header.php'; ?>
<?php include 'include/nav.php'; ?>


<div class="page_header text-center">
</br>
</br>
</br>
  <h2>Contact Us</h2>
  <p>If you have any questions, you can contact us by <a style="color: blue" href="mailto:aataie.ug@auaf.edu.af">emailing us</a>.</p>
</div>

<?php include 'include/footer.php' ?>
