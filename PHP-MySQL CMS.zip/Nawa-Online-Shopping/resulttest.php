<?php

require_once 'config/connect.php';
include 'include/header.php'; ?>
<?php include 'include/nav.php';
if (isset($_POST) & !empty($_POST)) {
     $prodName = $_POST['productSearch'];
     echo $prodName;
     $searchQuery = "SELECT * FROM products WHERE name LIKE '%$prodName%'";
     $result = mysqli_query($connection, $searchQuery) or die(mysqli_error($connection));
     $count = mysqli_num_rows($result);
     echo $count;
   } else {
     echo "search failed";
   }

 ?>
