<?php
session_start();
require_once 'config/connect.php';
include 'include/header.php';
include 'include/nav.php';
$cart = $_SESSION['cart'];
?>

	<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>Shopping Cart</h2>
						<p>Products You've selected!</p>
					</div>
					<div class="col-md-12">

<table class="cart-table table table-bordered">
				<thead>
					<tr>
						<th style="background: #1A76BA">&nbsp;</th>
						<th style="background: #1A76BA">&nbsp;</th>
						<th style="background: #1A76BA">Product</th>
						<th style="background: #1A76BA">Price</th>
						<th style="background: #1A76BA">Quantity</th>
						<th style="background: #1A76BA">Total</th>
					</tr>
				</thead>
				<tbody>
				<?php
				$total = 0;
					foreach ($cart as $key => $value) {
						$cartQuery = "SELECT * FROM products WHERE id=$key";
						$cartResult = mysqli_query($connection, $cartQuery);
						$cartr = mysqli_fetch_assoc($cartResult);


				 ?>
					<tr>
						<td>
							<a class="remove" href="delcart.php?id=<?php echo $key; ?>"><i class="fa fa-times"></i></a>
						</td>
						<td>
							<a href="#"><img src="admin/<?php echo $cartr['thumb']; ?>" alt="" height="90" width="90"></a>
						</td>
						<td>
							<a href="single.php?id=<?php echo $cartr['id']; ?>"><?php echo substr($cartr['name'], 0 , 30); ?></a>
						</td>
						<td>
							<span class="amount">Afs<?php echo $cartr['price']; ?>.00</span>
						</td>
						<td>
							<div class="quantity"><?php echo $value['quantity']; ?></div>
						</td>
						<td>
							<span class="amount">Afs<?php echo ($cartr['price']*$value['quantity']); ?>.00</span>
						</td>
					</tr>
				<?php
					$total = $total + ($cartr['price']*$value['quantity']);
				} ?>
					<tr>
						<td colspan="6" class="actions">
							<div class="col-md-6">
							</div>
							<div class="col-md-6">
								<div class="cart-btn">
									<a href="checkout.php" class="button btn-md" style="background: #1A76BA">Checkout</a>
								</div>
							</div>
						</td>
					</tr>
				</tbody>
			</table>

			<div class="cart_totals">
				<div class="col-md-6 push-md-6 no-padding">
					<h4 class="heading">Cart Totals</h4>
					<table class="table table-bordered col-md-6">
						<tbody>
							<tr>
								<th>Cart Subtotal</th>
								<td><span class="amount">Afs <?php echo $total; ?>.00</span></td>
							</tr>
							<tr>
								<th>Shipping</th>
								<td>
									Free Shipping
								</td>
							</tr>
							<tr>
								<th>Total Price</th>
								<td><strong><span class="amount">Afs <?php echo $total; ?>.00</span></strong> </td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>

					</div>
				</div>
			</div>
		</div>
	</section>
<?php include 'include/footer.php' ?>
